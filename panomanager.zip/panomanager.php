<?php

/*
Plugin Name: Pano Manager
Plugin URI: http://dan-blair.ca
Description: Manage your KR Panos
Version: 0.1.5
Author: Trying On The Trades
Author URI: http://www.tott.com
*/

// Originally developed by Dann Blair
// boldinnovationgroup.net

add_shortcode("pano", "pano_handler");
add_action('admin_menu', 'pano_create_menu');
add_action( 'admin_post_pano', 'process_pano' );
register_activation_hook( __FILE__, 'pano_install' );

// Version of the DB used
define( 'PANO_DB_VERSION', '0.0.2' );

// Require the important functions
require_once("functions/database.php");
require_once("functions/functions.php");
require_once("functions/processing.php");
require_once("functions/install.php");
require_once("functions/uninstall.php");
require_once("functions/menu.php");

// Require the objects
require_once("includes/pano.php");
require_once("includes/quest.php");

// Require the admin pages
require_once("admin/admin_page.php");
require_once("admin/quests.php");