# README #

this is the main plugin for Trying on The Trades. This plugin is for managing and maintaining exisiting KRPannos

### What is this repository for? ###

* this is the main plugin

### How do I get set up? ###

* Install App
* Add pannos
* profit

### Contribution guidelines ###

* Getting involced

### Who do I talk to? ###

* Guy Dugas