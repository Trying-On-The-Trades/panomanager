<?php

class quest{
	
	function __construct(){

	}
}